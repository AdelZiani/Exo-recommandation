def concat (n):
    L = []
    for i in range(n):
        L =  [i]+L
    return L