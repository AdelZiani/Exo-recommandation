def range_plus_fin(n):
    L = []
    for i in range(1, n+1):
        L = L + [i]

    return L