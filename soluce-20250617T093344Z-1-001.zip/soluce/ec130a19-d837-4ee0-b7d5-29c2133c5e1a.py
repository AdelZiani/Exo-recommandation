def diviseurs(x, l):
    return [i for i in l if x % i == 0]