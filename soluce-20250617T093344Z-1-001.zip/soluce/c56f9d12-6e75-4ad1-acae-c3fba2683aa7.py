def insertion_triee(liste, element):
    liste.append(element)
    liste.sort()