def somme(L):

    return sum(L)