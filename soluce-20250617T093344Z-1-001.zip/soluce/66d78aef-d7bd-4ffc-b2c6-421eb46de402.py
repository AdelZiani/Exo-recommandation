def range_insert(n):
    l=[]
    for i in range(n):
        l.insert(i,i+1)
    return l