def range_append(n):
    L = []
    for i in range(1, n+1):
        L.append(i)
    return L

# return [i for i in range(1, n+1)]